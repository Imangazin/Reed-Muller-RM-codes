Readme.txt

COSC-5P01
Project-Construction and Decoding methods of Reed-Muller codes

How to run "Reed-Muller":

This code was tested on NetBeans IDE 82.

************************************************************************************

Change parameters for code in the text file "parameters.txt" at src/parameters.txt

Parameters:

Chose easier (1) Code construction only for RM(r,m)
	  or (2) for decoding files using majority logic algorithm
	
Enter r, m values.

Enter number of errors for Noise channel

***********************************************************************************
	
After compile two output files generates (if chosen (2) earlier)

outputText.txt : text file after decoding

outputImage.jpg : image after decoding (if ther are many errors in the noise channel it may not 
open correctly, try to run again)

If chosen only construction of generator matrix for RM(r,m) then output displayed in the console.


 