package reedmuller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
/*
This class is main class for Reed Muller (RM) code application
-It implements generator matrix for RM
@author by Nurbek Imangazin
Project for COSC 5P01
*/
public class ReedMuller {
   
    int [][] firstOrderGM;
    static int distance;
    //generates first order generator matrix for RM
    // using binary representations of integers
    public void firstOrderGenMatrix (int m){

        int n = (int) Math.pow(2, m);
        int [][] genMatrix = new int [m+1][n];

        for(int i =0; i<n; i++){
            String str = Integer.toBinaryString(i);           
            while(str.length()<m){
                str = "0"+str;
            }           
            str = "1"+str;
            for(int j=0; j<m+1; j++){
                genMatrix[j][i]=Character.getNumericValue(str.charAt(j));                
            }
        }
        this.firstOrderGM = genMatrix;
    }
    
    public static void printGenMatrix(ArrayList<String> genMatrix){ 
        for(int i=0; i<genMatrix.size(); i++){
                System.out.println(genMatrix.get(i));                              
        }
    }
    //generates r-th order generator matrix for RM
    //takes first order and adds rest of the rows
    public ArrayList<String> genMatrixRM (int r, int m){                      
        firstOrderGenMatrix(m);
        ArrayList<String> genMatrix = new ArrayList<>();
           
        if (r==0){
            this.distance = (int) Math.pow(2, m-r);
            String allOne="";
            for (int i=0; i<(int) Math.pow(2, m); i++){
                allOne+="1";
            }
           genMatrix.add(allOne);
           return genMatrix;
        }
           
        for (int[] firstOrderGM1 : this.firstOrderGM) {
            String s="";
            for (int j = 0; j<this.firstOrderGM[0].length; j++) {
                s += firstOrderGM1[j];
            }
            genMatrix.add(s);
        }
     
        if (r==1){
            this.distance = (int)Math.pow(2, m-r);
            return genMatrix;
        }          
        for(int i=0; i<r-1; i++){
            String str = combinations(i+2,firstOrderGM.length-1);           
            for(String line: str.split(" ")){
                int count = 0;
                String each=genMatrix.get(Character.getNumericValue(line.trim().charAt(count)));                
                while(line.length()>count+1){
                    each = vectorCompare(each,genMatrix.get(Character.getNumericValue(line.trim().charAt(count+1))));
                    count++;
                }
                genMatrix.add(each);
            }      
        }   
        this.distance = (int)Math.pow(2, m-r);
        return genMatrix;
    }
      
    public String vectorCompare(String first, String second){
        String result="";
        for(int i=0; i<first.length(); i++){
            if(first.charAt(i)=='1' && second.charAt(i)=='1') 
                result+=1;
            else result+=0;
        }
        return result;
    }
    
    public static String bitprint(int u){           
        String s= "";
        for(int n= 1;u > 0;++n, u>>= 1)
            if((u & 1) > 0) s+= n;
        return s;
    }
 
    public static int bitcount(int u){
        int n;
        for(n= 0; u > 0;++n, u&= (u - 1));
        return n;
    }
 
    public static String combinations(int c, int n){
        String s= "";                
        for(int u= 1;u < 1 << n;u++) 
            if(bitcount(u) == c) s+=bitprint(u)+" ";
        return s;
    }
    //Noise channel
    //makes random errors in encoded data
    public String noiseChannel(String text, int error, int flag){
        String newResult="";
        double random=0;
        if (flag==1) random = 0.02;
        else random = 0.8;
        for (String each: text.split("\\s")){
            if (Math.random()<random){
                char [] ch = each.toCharArray();
                for (int i=0; i<error; i++){
                    if (ch[i]=='1') ch[i]='0';
                    if (ch[i]=='0') ch[i]='1';
                }
                each="";
                for(int i=0; i<ch.length; i++){
                    each+=ch[i];
                }
                newResult+=each+" ";
            } else newResult+=each+" ";
        }
        return newResult;
    }
    
    public static void main(String[] args) throws Exception {
        //reading parameters choesed by user
        Parameters parameters = new Parameters();
        ReedMuller x = new ReedMuller();
        if (parameters.getChoise()==1){ //prints only generator matrix for RM(r,m)
            System.out.println("You have choosed generating RM(r,m): ");
            if (parameters.getR()<0 || parameters.getR()>parameters.getM()) {
                System.out.print("Incorrect enrty of r");   
            }else {            
                System.out.println("G("+parameters.getR()+","+parameters.getM()+"):");
                printGenMatrix(x.genMatrixRM(parameters.getR(), parameters.getM()));
                System.out.println("Code can correct: "+(distance-1)/2+" errors");
            }
        }
        
        if (parameters.getChoise()==2){ // decoding files using RM(1,m)
            System.out.println("You have choosed decoding image and text file withing RM(1,"+parameters.getM()+"): ");
            Data data = new Data(x.genMatrixRM(1, parameters.getM()).size(),parameters.getFilName());
            EncodeDecode code = new EncodeDecode(); 
            String encodedFile = "";        
            encodedFile = code.encode(x.genMatrixRM(1,parameters.getM()), data.fileInBits);
            encodedFile = x.noiseChannel(encodedFile, parameters.getNumberOfErrors(),1);
            String output = code.majorityDecoding(x.genMatrixRM(1, parameters.getM()), encodedFile);        
            byte [] bytesFile = data.getBytes(output);
            data.writeBytesToFile(bytesFile);
            
            String encodedText= "";
            data.textData(x.genMatrixRM(1, parameters.getM()).size(), parameters.getText());
            encodedText = code.encode(x.genMatrixRM(1,parameters.getM()), data.textInBits);
            encodedText = x.noiseChannel(encodedText, parameters.getNumberOfErrors(),2);
            String outputText = code.majorityDecoding(x.genMatrixRM(1, parameters.getM()), encodedText);        
            byte [] bytesText = data.getBytes(outputText);
            data.writeTextBytesToFile(bytesText);
            
            System.out.println("Code can correct: "+(distance-1)/2+" errors");
            System.out.println();
            System.out.println("Decoded Image file can be found at src/outputImage.jpg");
            System.out.println("Decoded Text file can be found at src/outputText.txt");
            if (parameters.getNumberOfErrors()>(distance-1)/2)
                System.out.println("Result files may have some noise: errors in noise channel ("
                        +parameters.getNumberOfErrors() +") more than code can correct (" +(distance-1)/2+")");
            else 
                System.out.println("All errors successfully corrected: errors in noise channel ("
                        +parameters.getNumberOfErrors() +") less than code can correct ("+(distance-1)/2+")");
        }        
        
    }     
}
