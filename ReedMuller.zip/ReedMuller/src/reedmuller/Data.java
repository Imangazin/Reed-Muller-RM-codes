/*
 * This class handles conversion of files into bytes and bits
and vise verse
 */
package reedmuller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;


public class Data {
  String OUTPUT_FILE_NAME = "src/outputImage.jpg";
  String OUTPUT_TEXT_NAME = "src/outputText.txt";
  String fileInBits="";
  String textInBits="";
  //ArrayList<String> devidedBits;
  byte [] fileinBytes;
  //reads image and converts to bits
  public Data (int row, String fileName) throws IOException{
    this.fileinBytes = readFileToBytes(fileName);
    for(byte b : this.fileinBytes){
        this.fileInBits+=getBits(b);
    }
    
    int count=0;
    String line="";
    while (count<=fileInBits.length()-row){
       line+=fileInBits.substring(count, count+row)+" ";
       count=count+row;
    }    
    this.fileInBits=line;
  } 
  //reads text file and converts to bytes and bits
  public void textData (int row, String text) throws IOException{
    byte[] bytes = Files.readAllBytes(Paths.get(text));
    String codeWord ="";
    for(byte each: bytes)
    codeWord+= getBits(each);
    int count=0;
    String line="";
    while (count<=codeWord.length()-row){
        line+=codeWord.substring(count, count+row)+" ";
        count=count+row;
    }
    textInBits = line;
  }
  //conversion from image to bytes
  public byte[] readFileToBytes(String fileName) throws IOException {
    Path path = Paths.get(fileName);
    return Files.readAllBytes(path);
  }
  //writes bytes to image file
  public void writeBytesToFile(byte[] bytes) throws IOException {
    Path path = Paths.get(OUTPUT_FILE_NAME);
    Files.write(path, bytes);
  }
 //writes bytes to text file
  public void writeTextBytesToFile(byte[] bytes) throws IOException {
    Path path = Paths.get(OUTPUT_TEXT_NAME);
    Files.write(path, bytes);
  }
  //conversion from bytes to bits
  public String getBits(byte bytes){
    String result = "";  
        result=Integer.toBinaryString(bytes&0xFF);    
        while(result.length()<8){
        result="0"+result;
        }  
    return result;
  }
  
  public byte [] getBytes(String data){
      ArrayList<Byte> bytes = new ArrayList<>();
      int count=0;
        while (count<=data.length()-8){
           bytes.add((byte)Integer.parseInt(data.substring(count, count+8),2));
           count=count+8;
        }
        byte [] result = new byte[bytes.size()];
      for(int i=0; i<result.length; i++){
          result[i]=bytes.get(i);
      }      
      return result;
  }
}
