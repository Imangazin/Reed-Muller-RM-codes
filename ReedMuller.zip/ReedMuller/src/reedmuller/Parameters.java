/*
 *This class handles user parameters
 */
package reedmuller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;


public class Parameters {
    private static int choise;
    private static int m;
    private static int r;
    private static String fileName;
    private static String text;
    private static int numberOfErrors;
    public int  getChoise(){
        return choise;
    }
    public int getM(){return m;}
    public int getR(){return r;}
    public String getFilName(){return fileName;}
    public String getText(){return text;}
    public int getNumberOfErrors(){return numberOfErrors;}
    public Parameters (){
        BufferedReader readerParameters;
        try{
            readerParameters = new BufferedReader(new FileReader("src/parameters.txt"));
            String line = readerParameters.readLine();
            for(;;){
                if (line==null) break;
                if(line.startsWith("//")||(line.equals(""))){
                    line=readerParameters.readLine();
                    continue;
                }
                line.trim();
                String [] str = line.split(":");
                if (str[0].trim().equalsIgnoreCase("Construction or Decoding"))
                    choise = Integer.parseInt(str[1].trim());
                if (str[0].trim().equalsIgnoreCase("m"))
                    m = Integer.parseInt(str[1].trim());
                if (str[0].trim().equalsIgnoreCase("r"))
                    r = Integer.parseInt(str[1].trim());
                if (str[0].trim().equalsIgnoreCase("fileName"))
                    fileName = str[1].trim();
                if (str[0].trim().equalsIgnoreCase("text"))
                    this.text = str[1].trim();
                if (str[0].trim().equalsIgnoreCase("error"))
                    numberOfErrors = Integer.parseInt(str[1].trim());
                line = readerParameters.readLine();
            }
            readerParameters.close();
            
        }catch (IOException e){
            
        }
    }
    
}
