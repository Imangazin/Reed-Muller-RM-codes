/*
 * Handles encoding and decoding algorithms
 */
package reedmuller;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Nurbek
 */
public class EncodeDecode {
    //encoding using RM(1,m)
    public String encode(ArrayList<String> genMatrix, String data){
        String result="";
        for (String each: data.split("\\s")){
            String line=constMultipl(each.trim().charAt(0),genMatrix.get(0));
            for (int i=1; i<each.length(); i++){
                line = addBinary(line, constMultipl(each.trim().charAt(i),genMatrix.get(i)));
            }
            result+=line+" ";
        }
        
        return result;
    }
    //decoding using RM(1,m) with majority logic algorithm
    public String majorityDecoding(ArrayList<String> genMatrix, String recieve){
        String result="";       
        for(String each: recieve.split("\\s")){
            String original="";
            for(int i=genMatrix.size()-1; i>=1;i--){   
                original=checkSum(genMatrix.get(i),each)+original;
            }
            String z=constMultipl(original.charAt(0),genMatrix.get(1));
            for(int i=2; i<genMatrix.size(); i++){
                z=addBinary(z,constMultipl(original.charAt(i-1),genMatrix.get(i)));
            }
            z=addBinary(z,each);
            int zero=0; int one=0;
            for (int i=0;i<z.length();i++){
                if(z.charAt(i)=='1') one++;
                else zero++;
            }
            if(zero>one) original='0'+original;
            else original='1'+original;
            
            result+=original;
        }        
        return result;
    }
    
    
    public char addChar(char ch1, char ch2) {   
        if(ch1=='0' && ch2=='0') return '0';
        else
        if(ch1=='1' && ch2=='1') return '0';
        else
        if(ch1=='0' && ch2=='1') return '1';
        else return '1';
    }
    //check sums for decoding methods
    public char checkSum (String v, String codeword){
        char [] vCh = v.toCharArray();
        char [] codeCh = codeword.toCharArray();
        ArrayList<Integer> zeros = new ArrayList<>();
        ArrayList<Integer> ones = new ArrayList<>();
        String check="";
        for(int i = 0; i<vCh.length; i++){
            if (vCh[i]=='0')  zeros.add(i);
            else ones.add(i);
        }        
        for(int i=0; i<vCh.length/2; i++){
            check+=addChar(codeCh[zeros.get(i)],codeCh[ones.get(i)]);
        }       
        int z=0;int one=0;
        for (int i=0; i<check.length();i++){
            if(check.charAt(i)=='0') z++;
            else one++;
        }       
        if (z>one) { return '0'; }
        else {return '1';}       
    }
    
    public String constMultipl(char a, String x){
        char [] ch = x.toCharArray();
        for (int i=0; i<x.length(); i++){
            if(ch[i]=='0' && a=='0') ch[i]='0';
            if(ch[i]=='1' && a=='1') ch[i]='1';
            if(ch[i]=='0' && a=='1') ch[i]='0';
            if(ch[i]=='1' && a=='0') ch[i]='0';
        }
        x="";
        for(char each:ch){
            x+=each;
        }
        return x;
    }
    
    public String addBinary (String str1, String str2){
        char [] ch1 = str1.toCharArray();
        char [] ch2 = str2.toCharArray();
        String res="";
        for (int i=0; i<str1.length(); i++){
            if(ch1[i]=='0' && ch2[i]=='0') res+='0';
            if(ch1[i]=='1' && ch2[i]=='1') res+='0';
            if(ch1[i]=='0' && ch2[i]=='1') res+='1';
            if(ch1[i]=='1' && ch2[i]=='0') res+='1';
        }
        return res;
    }
}
